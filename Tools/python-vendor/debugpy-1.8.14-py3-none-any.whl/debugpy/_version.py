def get_versions():
    return {"version": "1.8.14", "full-revisionid": "", "dirty": False, "error": None, "date": None}
